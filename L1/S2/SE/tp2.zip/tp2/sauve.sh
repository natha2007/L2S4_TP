#!/bin/bash

if ! [[ $# -eq 2  ]]
then
	echo "il faut 2 paramères"
	exit 1
fi

if [ $
