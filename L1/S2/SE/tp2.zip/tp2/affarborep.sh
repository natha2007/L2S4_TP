#!/bin/bash

if [ $# -eq 1 ]
then
	cd $1
fi

rep=`pwd`
ch='/'

while [ $rep != $ch ]
do
	pwd
	cd ..
done
